import React, { Component } from 'react';
import { Image } from 'react-native';
import { Icon } from 'react-native-material-design';
import App from './src/components/Main.js';
import { Provider } from 'react-redux';
import configureStore from './src/store/configureStore';
import {Tab,Tabs,Container} from 'native-base';
import {
  AppRegistry,
  StyleSheet,
  View
} from 'react-native';

const store=configureStore();
export default class OPDPLUS extends Component {
  constructor() {
     super();

     console.ignoredYellowBox = [
         'Setting a timer'
     ];
 }
  render() {
    return (
      <Provider store={store}>
       <App />
      </Provider>
    );
  }
}



AppRegistry.registerComponent('OPDPLUS', () => OPDPLUS);
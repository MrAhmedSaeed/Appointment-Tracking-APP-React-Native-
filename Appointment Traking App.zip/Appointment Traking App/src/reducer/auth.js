export default function Reducer(state=[],action){
	
	switch(action.type)
	{
		case 'LOGIN':
            return [...state,
		           Object.assign({},action.Record)
		          ];
		 case 'DOC_TRACKING': 
            return [...state,
		           Object.assign({},action.Record)
		          ]; 
		 case 'CURRENT_PATIENT':
		 	return[...state,
		 		   Object.assign({},action.Record)
		 		   ];  
		 case 'PatientNumberPlus':
		 	return[...state,
		 		   Object.assign({},action.Record)
		 		   ];                    
		default:
		return state;
	}
}
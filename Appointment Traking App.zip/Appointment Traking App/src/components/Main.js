import React, { Component } from 'react';

import Login from './patient/login';
import Secured from './patient/secured';
import Signup from './patient/signup';
import Doctor from './doctor';
import Dashboard from './doctor/dashboard';
import Doc_Login from './doctor/login';
import Admin from './admin/Admin';
import A_login from './admin/A_login';
import {View,Text} from 'react-native';
import {Scene, Router} from 'react-native-router-flux';
const TabIcon = ({ selected, title }) => {
  return (
    <Text style={{color: selected ? 'red' :'black'}}>{title}</Text>
  );
}
class App extends React.Component{
  constructor() {
     super();

     console.ignoredYellowBox = [
         'Setting a timer'
     ];
 }
	
	render(){
		return(
			<Router>
		      <Scene key="root">
				        <Scene
				          key="tabbar"
				          tabs={true}
				          tabBarStyle={{backgroundColor: '#19BCB9', borderColor: '#e6e7e9', borderBottomWidth: 1 }}
		                >
          
          
            <Scene key="Patients">
            <Scene key="login"
              component={Login}
              hideNavBar={true}
            />
            <Scene
              key="secured"
              component={Secured}
              hideNavBar={true}
            />
            
            <Scene
              key="signup"
              component={Signup}
              
            />
          </Scene>

          
          <Scene key="Admin" >
          <Scene
              key="login"
              component={A_login}
              hideNavBar={true}
            />
            <Scene
              key="Admin"
              component={Admin}
              tittle="logout"
            />
            
          </Scene>

          
          <Scene key="Doctor" >
          <Scene
              key="doc_login"
              component={Doc_Login}
             hideNavBar={true}
            />
            
            <Scene
              key="dashboard"
              component={Dashboard}
            />
            
            
          </Scene>
        </Scene>
		      </Scene>
    </Router>);

	}
}





export default App;
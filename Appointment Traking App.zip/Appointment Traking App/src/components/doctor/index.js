import React, { Component } from 'react';
import {Scene, Router} from 'react-native-router-flux';
import Login from './login';

class Doctor extends React.Component{
	
	render(){
		return(
			<Login />);

	}
}





export default Doctor;
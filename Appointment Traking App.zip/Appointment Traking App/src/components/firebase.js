import firebase from 'firebase';

var config = {
    apiKey: "AIzaSyC8MeqX0doCF1oyEOZSgn9FL1X9rp7Y5h0",
    authDomain: "opdplus-44520.firebaseapp.com",
    databaseURL: "https://opdplus-44520.firebaseio.com",
    projectId: "opdplus-44520",
    storageBucket: "",
    messagingSenderId: "750533812426"
  };
  firebase.initializeApp(config);

  export default firebase;
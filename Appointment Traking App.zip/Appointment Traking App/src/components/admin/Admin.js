import React, { Component,PropTypes} from 'react';
import {Tab,Tabs,Container,Content,Form,Item,Input,Button} from 'native-base';
import { Icon } from 'react-native-material-design';
import {View,Image,Text} from 'react-native';
import DatePicker from 'react-native-datepicker'
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import * as authActions from '../../actions/actions';
class Admin extends React.Component{
	constructor(props){
    super(props);
    this.state={
    Appointment:{  contact:'',
              name:'',
               date: '',
               drn:'',
               appoint_no: ''}
             };
      }

  handleform(event){
     event.preventDefault();
     var Contact=this.state.contact;
     var Name=this.state.name;
      var date=this.state.date;
      var Drn=this.state.drn;
      var Appointment_no=this.state.appoint_no;

     const record=this.state.Appointment;
      record.contact=Contact;
      record.name=Name;
      record.date=date;
      record.drn=Drn;
      record.appoint_no=Appointment_no;

      
      this.setState({Appointment:record});
      this.props.actions.Appointments(this.state.Appointment);
            
      
      

      
      

  }
	render(){
		return(
		<Container style={{backgroundColor:'#19BCB9',padding:5}}>
        
        <Content style={{backgroundColor:'white'}}>
        <Image 
          source={{uri: 'http://trykrlo.com/logo.gif'}}
          style={{height: 150, width: 150,marginLeft:100,marginTop:40}}
          />
          <Form>
          <Item fixedLabel last>
            <Icon active name='lock-open' color='#19BCB9' />
              <Input onChangeText={(drn)=>this.setState({drn})} placeholder="DRN" />
            </Item>
            <Item fixedLabel>
            <Icon active name='people' color='#19BCB9' /> 
              <Input onChangeText={(name)=>this.setState({name})} placeholder="Patient Name" />
            </Item>
           <Item fixedLabel>
            <Icon active name='phone' color='#19BCB9' /> 
              <Input onChangeText={(contact)=>this.setState({contact})} placeholder="Contact Number" />
            </Item>
            <Item fixedLabel last>
            <Icon active name='supervisor-account' color='#19BCB9' />
              <Input onChangeText={(appoint_no)=>this.setState({appoint_no})} placeholder="Appointment Number" />
            </Item>
            <Item fixedLabel>
            <DatePicker
        style={{width: 300,borderWidth:0}}
        date={this.state.date}
        mode="date"
        pplaceholderText="select date"
        format="YYYY-MM-DD"
        minDate="2017-06-08"
        maxDate="2020-06-08"
        confirmBtnText="Confirm"
        cancelBtnText="Cancel"
        customStyles={{
          dateIcon: {
            position: 'absolute',
            left: 0,
            top: 4,
            marginLeft: 0
          },
          dateInput: {
            marginLeft: 36
          }
          
        }}
        onDateChange={(date) => {this.setState({date: date})}}
      />
            </Item>
            
            
           <Text>
          {"\n"}
          </Text>
         <Button onPress={this.handleform.bind(this)} rounded block info style={{width:300,marginLeft:25,borderRadius:5}}>
            <Text style={{fontSize:22,color:'white'}}>Submit</Text>
          </Button>
          <Text>
          {"\n"}
          </Text>
          </Form>
        </Content>
      </Container>
			);
	}
}
Admin.propsTypes={
  actions:PropTypes.object.isRequired
};

function mapDispatchToProps(dispatch)
{
  return{
    actions:bindActionCreators(authActions,dispatch)
  };
}
function mapStateToProps(state){
  
  return{
    auth:state.auth
  };
}
const connectedStateAndProps=connect(mapStateToProps,mapDispatchToProps);
export default connectedStateAndProps(Admin);


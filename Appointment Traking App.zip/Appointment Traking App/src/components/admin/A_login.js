import React, { Component,PropTypes } from 'react';
import { Image,TextInput,Text,View } from 'react-native';
import {Actions} from 'react-native-router-flux';
import { Icon } from 'react-native-material-design';
import { Container, Header, Title, Content,Card, CardItem,Form,Item,Label,Input, Footer, FooterTab, Button, Left, Right, Body} from 'native-base';
import * as authActions from '../../actions/actions';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
class ALogin extends React.Component{
  constructor(props){
    super(props);
    this.state={
    Record:{isLoggedIn:false,
               eamil: '',
               password: ''}
             };
      }

  handleLogin(event){
     event.preventDefault();
      var Email=this.state.email;
      var Password=this.state.Password;

       const record=this.state.Record;
      record.isLoggedIn=true;
      record.email=Email;
      record.password=Password;

      
      this.setState({Record:record});
      this.props.actions.A_login(this.state.Record);
      }

      handleSignup(event)
      {
        event.preventDefault();
        Actions.signup();
      }
	render(){
		return(
      
          <Container style={{backgroundColor:'#19BCB9',padding:5}}>
        
        <Content style={{backgroundColor:'white'}}>
          <Image 
         source={require('../../images/logo.gif')}
          style={{height: 150, width: 150,marginLeft:100,marginTop:40}}
          />
           <Text>
          {"\n\n\n"}
          </Text>
          <Form>
            <Item fixedLabel>
            <Icon active name='email' color='#19BCB9' /> 
              <Input onChangeText={(email)=>this.setState({email})} placeholder="Email" />
            </Item>
            <Item fixedLabel last>
            <Icon active name='lock-open' color='#19BCB9' />
              <Input onChangeText={(Password)=>this.setState({Password})} placeholder="Password" />
            </Item>
           <Text>
          {"\n"}
          </Text>
          <Button onPress={this.handleLogin.bind(this)} rounded block info style={{width:300,marginLeft:25,borderRadius:5}}>
            <Text style={{fontSize:22,color:'white'}}>Login</Text>
          </Button>
          </Form>
         
        </Content>

       
      </Container>


			);
	}
}

ALogin.propsTypes={
  actions:PropTypes.object.isRequired
};

function mapDispatchToProps(dispatch)
{
  return{
    actions:bindActionCreators(authActions,dispatch)
  };
}
function mapStateToProps(state){
  
  return{
    auth:state.auth
  };
}
const connectedStateAndProps=connect(mapStateToProps,mapDispatchToProps);
export default connectedStateAndProps(ALogin);
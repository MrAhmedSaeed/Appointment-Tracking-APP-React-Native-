import React, { Component,PropTypes } from 'react'
import DatePicker from 'react-native-datepicker'
import { Icon } from 'react-native-material-design';
import { Image,TextInput,Text,View } from 'react-native';
import { Container, Header, Title, Content,Card, CardItem,Form,Item,Label,Input, Footer, FooterTab, Button, Left, Right, Body} from 'native-base';
import * as authActions from '../../actions/actions';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import firebase from '../firebase';
class Patient_tarcking extends Component {
  constructor(props){
    super(props)
    this.state = {drn:'',
                 date:"2016-05-15",
                 track:true,
                 current_patient:0}
  }
  handletrack(){
   var CP=0;
    var Drn=this.state.drn;
      var App_Date=this.state.date;
     var self=this;
      
       var ref=firebase.database().ref('Tracking/'+ Drn+ '/' +App_Date); 

      ref.on("value", function(snapshot) {
        if(snapshot.val()==null){
          alert("Sytem not started");
        }
        else{
          alert('ok');
         CP= snapshot.val().Current_patient_number;
        
        
        self.setState({track:false,current_patient:CP});
      }
      });

      
    

    
    }

  render(){
    var v=this.state;
      if(v.track){
    return (
    
     <Container style={{backgroundColor:'#19BCB9',padding:5}}>
        
        <Content style={{backgroundColor:'white'}}>
          <Image 
          source={{uri: 'http://trykrlo.com/logo.gif'}} 
          style={{height: 150, width: 150,marginLeft:100,marginTop:40}}
          />
           <Text>
          {"\n\n\n"}
          </Text>
          <Form>
            <Item fixedLabel>
            <Icon active name='email' color='#19BCB9' /> 
              <Input onChangeText={(drn)=>this.setState({drn})} placeholder="DRN" />
            </Item>
            <Item fixedLabel>
             <DatePicker
        style={{width: 300,borderWidth:0}}
        date={this.state.date}
        mode="date"
        pplaceholderText="select date"
        format="YYYY-MM-DD"
       minDate="2017-06-08"
        maxDate="2020-06-08"
        confirmBtnText="Confirm"
        cancelBtnText="Cancel"
        customStyles={{
          dateIcon: {
            position: 'absolute',
            left: 0,
            top: 4,
            marginLeft: 0
          },
          dateInput: {
            marginLeft: 36
          }
          
        }}
        onDateChange={(date) => {this.setState({date: date})}}
      />
      </Item>
           <Text>
          {"\n"}
          </Text>
          <Button onPress={this.handletrack.bind(this)} rounded block info>
            <Text style={{fontSize:22,color:'white'}}>submit</Text>
          </Button>
          </Form>
        </Content>

       
      </Container>
    
    )
  }
  else{
    return(
      <Container style={{backgroundColor:'#19BCB9',padding:5}}>
        
        <Content style={{backgroundColor:'white'}}>
          <Image 
          source={{uri: 'https://scontent.fkhi2-1.fna.fbcdn.net/v/t34.0-12/20117411_1346948672086481_2057560193_n.gif?fallback=1&oh=7b63a3f3829f2a4b7d3945a04ee55d76&oe=597645D1'}} 
          style={{height: 150, width: 150,marginLeft:100,marginTop:40}}
          />
           <Text>
          {"\n\n\n"}
          </Text>

          <Text style={{fontSize:18,color:'#19BCB9',textAlign:'center'}}>
             Patients are waiting 
          </Text>
          <View
  style={{
    borderBottomColor: '#19BCB9',
    borderBottomWidth: 2,
    marginBottom:10,
    marginTop:10,
  }}
/>
          <Text style={{borderWidth:1,borderColor:'#19BCB9',fontSize:24,color:'#19BCB9',padding:10,textAlign:'center'}}>
              Current Patient Number : {v.current_patient}
           </Text> 
           <Text>
          {"\n\n\n"}
          </Text>
           <Button onPress={this.handletrack.bind(this)} rounded block info>
            <Text style={{fontSize:22,color:'white',fontWeight:'bold'}}>Next</Text>
          </Button>  
        </Content>
      </Container>
      );
  }
  }
}

Patient_tarcking.propsTypes={
  actions:PropTypes.object.isRequired
};

function mapDispatchToProps(dispatch)
{
  return{
    actions:bindActionCreators(authActions,dispatch)
  };
}
function mapStateToProps(state){
  
  return{
    auth:state.auth
  };
}
const connectedStateAndProps=connect(mapStateToProps,mapDispatchToProps);
export default connectedStateAndProps(Patient_tarcking);
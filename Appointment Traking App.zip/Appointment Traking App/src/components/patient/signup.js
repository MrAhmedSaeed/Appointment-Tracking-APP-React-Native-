import React, { Component,PropTypes } from 'react';
import { Image,TextInput,Text,View,Picker } from 'react-native';
import { Icon } from 'react-native-material-design';
import { Container, Header, Title, Content,Card, CardItem,Form,Item,Label,Input, Footer, FooterTab, Button, Left, Right, Body} from 'native-base';
import * as authActions from '../../actions/actions';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
class Signup extends React.Component{
  constructor(props){
    super(props);
    this.state={
    Record:{  contact:'',
              name:'',
               email: '',
               gender:'',
               password: ''}
             };
      }

  handleform(event){
     event.preventDefault();
     var Contact=this.state.contact;
     var Name=this.state.name;
      var Email=this.state.email;
      var Gender=this.state.gender;
      var Password=this.state.Password;

     const record=this.state.Record;
      record.contact=Contact;
      record.name=Name;
      record.email=Email;
      record.gender=Gender;
      record.password=Password;

      
      this.setState({Record:record});
      this.props.actions.signup(this.state.Record);
      
      
      

      
      

  }
	render(){
		return(
      
          <Container style={{backgroundColor:'#19BCB9',padding:5}}>
        
        <Content style={{backgroundColor:'white'}}>
          
          <Image 
         source={require('../../images/logo.gif')} 
          style={{height: 150, width: 150,marginLeft:100,marginTop:40}}
          />
           <Text>
          {"\n"}
          </Text>
          <Form>
           <Item fixedLabel>
            <Icon active name='phone' color='#19BCB9' /> 
              <Input onChangeText={(contact)=>this.setState({contact})} placeholder="Contact number" />
            </Item>
            <Item fixedLabel>
            <Icon active name='people' color='#19BCB9' /> 
              <Input onChangeText={(name)=>this.setState({name})} placeholder="Name" />
            </Item>
            <Item fixedLabel>
            <Icon active name='email' color='#19BCB9' /> 
              <Input onChangeText={(email)=>this.setState({email})} placeholder="Email" />
            </Item>
            <Item fixedLabel last>
            <Icon active name='lock-open' color='#19BCB9' />
              <Input onChangeText={(Password)=>this.setState({Password})} placeholder="Password" />
            </Item>
            <Item fixedLabel last>
            <Icon active name='supervisor-account' color='#19BCB9' />
              <Input onChangeText={(gender)=>this.setState({gender})} placeholder="Gender" />
            </Item>
           <Text>
          {"\n"}
          </Text>
          <Button onPress={this.handleform.bind(this)} rounded block info style={{width:300,marginLeft:25,borderRadius:5}}>
            <Text style={{fontSize:22,color:'white'}}>Signup</Text>
          </Button>
          <Text>
          {"\n\n\n"}
          </Text>
          </Form>
        </Content>
       
      </Container>


			);
	}
}

Signup.propsTypes={
  actions:PropTypes.object.isRequired
};

function mapDispatchToProps(dispatch)
{
  return{
    actions:bindActionCreators(authActions,dispatch)
  };
}
function mapStateToProps(state){
  
  return{
    auth:state.auth
  };
}
const connectedStateAndProps=connect(mapStateToProps,mapDispatchToProps);
export default connectedStateAndProps(Signup);
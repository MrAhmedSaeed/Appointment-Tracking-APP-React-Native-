import {Actions} from 'react-native-router-flux';
import firebase from '../components/firebase';
export function login(Record){
    return function(dispatch){
    	var email=Record.email;
    var password=Record.password;
    var check=Record.isLoggedIn;
      
    
       firebase.auth().signInWithEmailAndPassword(email,password).catch(function(error) {
         
        check=false;
  
    });
       setTimeout(checkr, 500);
     function  checkr(){
        if(check)
       {
        Actions.secured();
       }
       else{
        console.log(check);
       }
       }
};
}
 
export function logout(){
    return {
        type: 'LOGOUT'
    }
};
 
export function signup(Record){
    return (dispatch) => {
      var email=Record.email;
      var password=Record.password;
      var name=Record.name;
      var contact=Record.contact;
      var gender=Record.gender;
      
    firebase.database().ref('Patients/' +contact).set({
    Name: name,
    Email: email,
    Gender:gender,
    Password:password
  });

    firebase.auth().createUserWithEmailAndPassword(email, password).catch(function(error) {
  
  var errorCode = error.code;
  var errorMessage = error.message;


});
    Actions.login();

    }
};

export function A_login(Record){
    return function(dispatch){
      var email=Record.email;
    var password=Record.password;
    var check=Record.isLoggedIn;
      
    
       firebase.auth().signInWithEmailAndPassword(email,password).catch(function(error) {
         
        check=false;
  
    });
       setTimeout(checkr, 500);
     function  checkr(){
        if(check)
       {
        Actions.Admin();
       }
       else{
        console.log(check);
       }
       }
};
}

export function Appointments(Record) {

  return function dispatch() {
    
       var DRN=Record.drn;
       var name=Record.name;
       var Contact=Record.contact;
       var date=Record.date;
       var Appointment_no=Record.appoint_no;

       firebase.database().ref('Appointments/'+ DRN+ '/' + date + '/' + Contact).set({
        Name:name,
        Appointment_Number:Appointment_no
       });

       alert('Appointment Successfully Added');

    
  }
  
}

export function Doc_login(Record) {
  return function dispatch() {
      var Contact=Record.phone;
      var password=Record.password;


       var RefData=firebase.database().ref("Doctors/");

    RefData.once("value").then(function(snapshot) {

    snapshot.forEach(function(childSnapshot) {
      
       var Phone = childSnapshot.key;
       if(Contact==Phone){
         var Password=childSnapshot.val().Password;
         if(Password==password)
         {
          
          Actions.dashboard();
         

         }
         else{
          alert('Worng Password');
         }
       }
       
  });

});

  }
};
export function updateDocAuthState(Record) {
  return{type:'DOC_TRACKING',Record}
}



export function updateDocTrackState(Record){
  return{type:"CURRENT_PATIENT",Record}
}

export function Doc_tracking(Record) {
  
  return function dispatch() {
    var DRN=Record.drn;
    var Ap_date=Record.date;
    var count=Record.current_patient;
    var TNOP=Record.total_no_of_patients;

    if(count==1)
    {
    firebase.database().ref('Tracking/'+ DRN+ '/' +Ap_date).set({
      Current_patient_number:count
    });
    
    }
  else{
    firebase.database().ref('Tracking/'+ DRN+ '/' +Ap_date).update({
      Current_patient_number:count
    });
   
  }
  }
}


export function updatePatientNumber(Record){
  return {type:'PatientNumberPlus',Record}
}

export function Number_tracking(Record){
  return function dispatch(){
    var DRN=Record.drn;
    var date=Record.date;
    var CPv=Record.current_patient;
    var Track=Record.track;
    alert(DRN);
    var self=this;
     const record=Record.current_patient;
    var ref=firebase.database().ref('Tracking/'+ DRN+ '/' +date); 

      ref.on("value", function(snapshot) {
        var CP= snapshot.val().Current_patient_number;
        r=CP;
});
    this.setState({
         current_patient:2
       });
  }.bind(this);
}